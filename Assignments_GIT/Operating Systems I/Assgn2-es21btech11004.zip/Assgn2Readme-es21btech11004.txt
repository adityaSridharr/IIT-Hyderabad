To execute the program, follow the instructions listed below:
1. Make sure you use a LINUX or macOS system. 

2. Compilation of the code : Enter the below written input line - 
		gcc Assgn2Src-es21btech11004.c
	An executable file is now created.

3. To run the executable, enter the below line
		./a.out "input.txt"

4. This executes the program. "input.txt" will be a file created by you; this will contain the values of n and k.

5. The code is now running. k + 1 files are created - one for each thread (OutFilei.txt) and one main output file (OutMain.txt)